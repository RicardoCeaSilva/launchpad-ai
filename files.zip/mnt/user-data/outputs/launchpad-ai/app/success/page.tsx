import Link from "next/link";
import { CheckCircle2 } from "lucide-react";

export default function SuccessPage() {
  return (
    <main className="min-h-screen bg-[#080809] text-white flex items-center justify-center px-6">
      <div className="text-center max-w-md">
        <div className="w-16 h-16 bg-green-500/10 border border-green-500/30 rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle2 size={32} className="text-green-400" />
        </div>
        <h1 className="text-4xl font-black mb-3">You&apos;re on Pro! 🚀</h1>
        <p className="text-white/50 mb-8">
          Your subscription is active. Start building unlimited projects with advanced AI models.
        </p>
        <Link
          href="/"
          className="inline-flex items-center gap-2 bg-gradient-to-r from-blue-500 to-purple-600 text-white font-bold px-6 py-3 rounded-xl hover:opacity-90 transition-opacity"
        >
          Start Building →
        </Link>
      </div>
    </main>
  );
}
